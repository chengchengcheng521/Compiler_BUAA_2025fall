package ast;


public interface Node {
}